/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.8-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: u353253270_lcds_db
-- ------------------------------------------------------
-- Server version	11.8.8-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `api_logs`
--

DROP TABLE IF EXISTS `api_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `endpoint` varchar(255) NOT NULL,
  `method` enum('GET','POST','PUT','DELETE','PATCH') NOT NULL,
  `direction` enum('inbound','outbound') NOT NULL,
  `external_system` enum('sifter','convoso','gohighlevel') NOT NULL,
  `request_headers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`request_headers`)),
  `request_body` text DEFAULT NULL,
  `response_status` int(10) unsigned DEFAULT NULL,
  `response_headers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`response_headers`)),
  `response_body` text DEFAULT NULL,
  `response_time_ms` int(10) unsigned DEFAULT NULL,
  `is_error` tinyint(1) DEFAULT 0,
  `error_message` text DEFAULT NULL,
  `lead_id` int(10) unsigned DEFAULT NULL COMMENT 'Set when call is lead-specific',
  `campaign_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_external_system` (`external_system`),
  KEY `idx_direction` (`direction`),
  KEY `idx_error` (`is_error`),
  KEY `idx_created` (`created_at`),
  KEY `idx_lead` (`lead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Complete API call audit log. All 3 platforms. 90-day retention.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_logs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `api_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `api_logs` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `batch_queue`
--

DROP TABLE IF EXISTS `batch_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `batch_queue` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `campaign_id` int(10) unsigned NOT NULL,
  `batch_name` varchar(255) NOT NULL,
  `batch_size` int(10) unsigned NOT NULL,
  `destination` enum('convoso','gohighlevel') NOT NULL,
  `lead_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'Array of lead IDs to send in this batch' CHECK (json_valid(`lead_ids`)),
  `queue_status` enum('pending','processing','completed','failed') DEFAULT 'pending',
  `sent_count` int(10) unsigned DEFAULT 0,
  `failed_count` int(10) unsigned DEFAULT 0,
  `error_message` text DEFAULT NULL,
  `scheduled_at` datetime DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `idx_campaign` (`campaign_id`),
  KEY `idx_status` (`queue_status`),
  KEY `idx_destination` (`destination`),
  KEY `idx_scheduled` (`scheduled_at`),
  CONSTRAINT `batch_queue_ibfk_1` FOREIGN KEY (`campaign_id`) REFERENCES `campaigns` (`id`) ON DELETE CASCADE,
  CONSTRAINT `batch_queue_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Async batch send queue. Processed by batch-processor.php cron.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batch_queue`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `batch_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `batch_queue` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `call_results`
--

DROP TABLE IF EXISTS `call_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `call_results` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `campaign_id` int(10) unsigned NOT NULL,
  `call_date` datetime NOT NULL,
  `call_disposition` varchar(100) NOT NULL COMMENT 'Convoso code: SALE, LEAD, NI, NA, BUSY, AM, DC, CALLBK, DNC',
  `sub_disposition` varchar(100) DEFAULT NULL,
  `agent_name` varchar(100) DEFAULT NULL,
  `agent_id` varchar(100) DEFAULT NULL,
  `call_duration_seconds` int(10) unsigned DEFAULT NULL,
  `talk_time_seconds` int(10) unsigned DEFAULT NULL,
  `recording_url` varchar(500) DEFAULT NULL COMMENT 'Convoso recording file URL',
  `agent_notes` text DEFAULT NULL,
  `is_qualified` tinyint(1) DEFAULT 0 COMMENT 'TRUE for SALE/LEAD/DM/APPOINTMENT dispositions',
  `qualification_score` tinyint(3) unsigned DEFAULT NULL,
  `source_system` varchar(50) DEFAULT 'convoso',
  `external_call_id` varchar(100) DEFAULT NULL COMMENT 'Convoso internal call log ID — prevents duplicate processing',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_lead` (`lead_id`),
  KEY `idx_campaign` (`campaign_id`),
  KEY `idx_disposition` (`call_disposition`),
  KEY `idx_qualified` (`is_qualified`),
  KEY `idx_call_date` (`call_date`),
  KEY `idx_external_id` (`external_call_id`),
  CONSTRAINT `call_results_ibfk_1` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE,
  CONSTRAINT `call_results_ibfk_2` FOREIGN KEY (`campaign_id`) REFERENCES `campaigns` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Call attempt records from Convoso. One row per call. Drives status updates.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `call_results`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `call_results` DISABLE KEYS */;
/*!40000 ALTER TABLE `call_results` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `campaigns`
--

DROP TABLE IF EXISTS `campaigns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `campaigns` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `campaign_name` varchar(255) NOT NULL,
  `campaign_code` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `convoso_campaign_id` varchar(100) DEFAULT NULL COMMENT 'Convoso Campaign ID from /v1/campaigns/search',
  `convoso_list_id` varchar(100) DEFAULT NULL COMMENT 'Convoso List ID — created via /v1/lists/insert',
  `ghl_pipeline_id` varchar(100) DEFAULT NULL COMMENT 'GoHighLevel Pipeline ID',
  `ghl_stage_id` varchar(100) DEFAULT NULL COMMENT 'GoHighLevel Stage ID for initial placement',
  `target_leads` int(10) unsigned DEFAULT 0,
  `batch_size` int(10) unsigned DEFAULT 1000 COMMENT 'Leads per batch sent to Convoso',
  `max_call_attempts` tinyint(3) unsigned DEFAULT 3 COMMENT 'Max retries before archiving',
  `status` enum('draft','active','paused','completed','archived') DEFAULT 'draft',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `campaign_code` (`campaign_code`),
  KEY `created_by` (`created_by`),
  KEY `idx_campaign_code` (`campaign_code`),
  KEY `idx_status` (`status`),
  KEY `idx_dates` (`start_date`,`end_date`),
  CONSTRAINT `campaigns_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Campaign definitions linking LCDS to Convoso and GoHighLevel';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaigns`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `campaigns` DISABLE KEYS */;
INSERT INTO `campaigns` VALUES
(1,'Default Campaign','DEFAULT','Auto-created for imports',NULL,NULL,NULL,NULL,0,1000,3,'active',NULL,NULL,1,'2026-03-14 12:48:54','2026-03-19 06:41:39'),
(2,'dummy campaign','DUMMYCAMPA29','this campaign is for test','','','','',0,1000,3,'active',NULL,NULL,1,'2026-03-17 12:16:43','2026-03-19 06:41:39');
/*!40000 ALTER TABLE `campaigns` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `compliance_logs`
--

DROP TABLE IF EXISTS `compliance_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `compliance_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned DEFAULT NULL,
  `campaign_id` int(10) unsigned DEFAULT NULL,
  `event_type` varchar(100) NOT NULL COMMENT 'scrub_check, dnc_check, expiry_warning, expired, dnc_added',
  `event_status` varchar(50) NOT NULL COMMENT 'pass, fail, warning',
  `details` text DEFAULT NULL,
  `scrub_date` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `days_until_expiry` int(11) DEFAULT NULL COMMENT 'Negative = already expired',
  `action_taken` varchar(255) DEFAULT NULL COMMENT 'What LCDS did in response to this event',
  `checked_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_lead` (`lead_id`),
  KEY `idx_campaign` (`campaign_id`),
  KEY `idx_event_type` (`event_type`),
  KEY `idx_event_status` (`event_status`),
  KEY `idx_date` (`checked_at`),
  CONSTRAINT `compliance_logs_ibfk_1` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE,
  CONSTRAINT `compliance_logs_ibfk_2` FOREIGN KEY (`campaign_id`) REFERENCES `campaigns` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='TCPA compliance audit trail. Legal retention: 2+ years. Do not purge.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compliance_logs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `compliance_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `compliance_logs` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `dnc_list`
--

DROP TABLE IF EXISTS `dnc_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `dnc_list` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phone` varchar(20) NOT NULL COMMENT 'Normalized 10-digit, no formatting',
  `reason` varchar(255) DEFAULT NULL,
  `source` varchar(100) DEFAULT NULL COMMENT 'national, company, customer_request, litigator',
  `lead_id` int(10) unsigned DEFAULT NULL COMMENT 'Lead that triggered this DNC entry',
  `campaign_id` int(10) unsigned DEFAULT NULL,
  `added_at` timestamp NULL DEFAULT current_timestamp(),
  `expires_at` date DEFAULT NULL COMMENT 'NULL = permanent',
  PRIMARY KEY (`id`),
  UNIQUE KEY `phone` (`phone`),
  KEY `lead_id` (`lead_id`),
  KEY `campaign_id` (`campaign_id`),
  KEY `idx_phone` (`phone`),
  KEY `idx_source` (`source`),
  KEY `idx_expiry` (`expires_at`),
  CONSTRAINT `dnc_list_ibfk_1` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE SET NULL,
  CONSTRAINT `dnc_list_ibfk_2` FOREIGN KEY (`campaign_id`) REFERENCES `campaigns` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Company DNC registry. Checked at import and before every batch send.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnc_list`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `dnc_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnc_list` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `file_imports`
--

DROP TABLE IF EXISTS `file_imports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `file_imports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `campaign_id` int(10) unsigned NOT NULL,
  `original_filename` varchar(255) NOT NULL,
  `stored_filename` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` int(10) unsigned NOT NULL COMMENT 'Bytes',
  `total_records` int(10) unsigned DEFAULT 0,
  `valid_records` int(10) unsigned DEFAULT 0,
  `failed_records` int(10) unsigned DEFAULT 0,
  `duplicate_records` int(10) unsigned DEFAULT 0,
  `import_status` enum('pending','processing','completed','failed') DEFAULT 'pending',
  `error_message` text DEFAULT NULL,
  `processed_at` datetime DEFAULT NULL,
  `processing_time_seconds` int(10) unsigned DEFAULT NULL,
  `imported_by` int(10) unsigned NOT NULL,
  `imported_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `imported_by` (`imported_by`),
  KEY `idx_campaign` (`campaign_id`),
  KEY `idx_status` (`import_status`),
  KEY `idx_date` (`imported_at`),
  CONSTRAINT `file_imports_ibfk_1` FOREIGN KEY (`campaign_id`) REFERENCES `campaigns` (`id`) ON DELETE CASCADE,
  CONSTRAINT `file_imports_ibfk_2` FOREIGN KEY (`imported_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='CSV import history with per-import statistics';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_imports`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `file_imports` DISABLE KEYS */;
INSERT INTO `file_imports` VALUES
(8,1,'sample.csv','csv_69b55a058fde34.70692992.csv','/home/u353253270/domains/landcaller.com/public_html/lcds/storage/csv/csv_69b55a058fde34.70692992.csv',11662,0,0,0,0,'failed','Missing required headers: first_name, last_name, scrub_date','2026-03-14 18:22:21',0,1,'2026-03-14 12:52:21'),
(9,1,'sample.csv','csv_69b55ac16908c0.90067916.csv','/home/u353253270/domains/landcaller.com/public_html/lcds/storage/csv/csv_69b55ac16908c0.90067916.csv',11662,105,105,0,0,'completed',NULL,'2026-03-14 18:25:29',0,1,'2026-03-14 12:55:29'),
(10,1,'sifter_sample.csv','csv_69b562fd5f9687.11544939.csv','/home/u353253270/domains/landcaller.com/public_html/lcds/storage/csv/csv_69b562fd5f9687.11544939.csv',269,2,2,0,0,'completed',NULL,'2026-03-14 19:00:37',0,1,'2026-03-14 13:30:37'),
(11,1,'sifter_sample.csv','csv_69b7a672788483.97202068.csv','/home/u353253270/domains/landcaller.com/public_html/lcds/storage/csv/csv_69b7a672788483.97202068.csv',269,2,2,0,0,'completed',NULL,'2026-03-16 12:12:58',0,1,'2026-03-16 06:42:58'),
(15,1,'lcds_import_template (1).csv','csv_69b7eabd7d77f2.67409909.csv','/home/u353253270/domains/landcaller.com/public_html/lcds/storage/csv/csv_69b7eabd7d77f2.67409909.csv',799,5,5,0,0,'completed',NULL,'2026-03-16 17:04:21',0,1,'2026-03-16 11:34:21'),
(16,1,'lcds_leads_100.csv','csv_69b801b9db2143.08461610.csv','/home/u353253270/domains/landcaller.com/public_html/lcds/storage/csv/csv_69b801b9db2143.08461610.csv',12782,100,100,0,0,'completed',NULL,'2026-03-16 18:42:26',0,1,'2026-03-16 13:12:25'),
(18,1,'lcds_import_template (2).csv','csv_69b92ff0460283.28408473.csv','/home/u353253270/domains/landcaller.com/public_html/lcds/storage/csv/csv_69b92ff0460283.28408473.csv',799,5,5,0,0,'completed',NULL,'2026-03-17 16:11:52',0,1,'2026-03-17 10:41:52'),
(19,1,'lcds_import_template (2).csv','csv_69b9352b7f9fa3.99985172.csv','/home/u353253270/domains/landcaller.com/public_html/lcds/storage/csv/csv_69b9352b7f9fa3.99985172.csv',799,5,5,0,0,'completed',NULL,'2026-03-17 16:34:11',0,1,'2026-03-17 11:04:11'),
(20,1,'lcds_import_template (2).csv','csv_69bba3c7462d08.25625168.csv','/home/u353253270/domains/landcaller.com/public_html/app/lcds/classes/../storage/csv/csv_69bba3c7462d08.25625168.csv',799,5,5,0,0,'completed',NULL,'2026-03-19 07:20:39',0,1,'2026-03-19 07:20:39');
/*!40000 ALTER TABLE `file_imports` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `imports_log`
--

DROP TABLE IF EXISTS `imports_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `imports_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) DEFAULT NULL,
  `rows_total` int(11) DEFAULT 0,
  `rows_inserted` int(11) DEFAULT 0,
  `rows_skipped` int(11) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imports_log`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `imports_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `imports_log` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `leads`
--

DROP TABLE IF EXISTS `leads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `leads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `campaign_id` int(10) unsigned NOT NULL,
  `import_id` int(10) unsigned NOT NULL,
  `lead_external_id` varchar(100) DEFAULT NULL COMMENT 'LeadID from Sifter CSV',
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL COMMENT 'Normalized 10-digit, no formatting',
  `email` varchar(255) DEFAULT NULL,
  `address` varchar(500) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL COMMENT '2-letter US state code',
  `zip` varchar(20) DEFAULT NULL COMMENT '5-digit or 5+4 format',
  `age` int(10) unsigned DEFAULT NULL,
  `home_value` decimal(12,2) DEFAULT NULL,
  `income_range` varchar(50) DEFAULT NULL,
  `custom_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Any additional Sifter fields not in fixed columns' CHECK (json_valid(`custom_data`)),
  `scrub_date` date NOT NULL COMMENT 'Date data was DNC-scrubbed by Sifter',
  `scrub_expiry_date` date GENERATED ALWAYS AS (`scrub_date` + interval 30 day) STORED COMMENT 'Auto-calculated: scrub_date + 30 days. Do not set manually.',
  `is_dnc` tinyint(1) DEFAULT 0,
  `dnc_date` datetime DEFAULT NULL,
  `dnc_reason` varchar(255) DEFAULT NULL,
  `lead_status` enum('imported','validated','failed_validation','sent_to_convoso','calling','called_no_answer','called_busy','called_voicemail','called_not_interested','called_callback','called_wrong_number','qualified_lead','sent_to_ghl','converted','inactive') DEFAULT 'imported',
  `quality_score` tinyint(3) unsigned DEFAULT NULL,
  `convoso_lead_id` varchar(100) DEFAULT NULL COMMENT 'Set after successful /v1/leads/insert',
  `ghl_contact_id` varchar(100) DEFAULT NULL COMMENT 'Set after GoHighLevel createContact()',
  `ghl_opportunity_id` varchar(100) DEFAULT NULL COMMENT 'Set after GoHighLevel createOpportunity()',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_phone` (`phone`),
  KEY `idx_email` (`email`),
  KEY `idx_status` (`lead_status`),
  KEY `idx_campaign` (`campaign_id`),
  KEY `idx_import` (`import_id`),
  KEY `idx_scrub_expiry` (`scrub_expiry_date`),
  KEY `idx_dnc` (`is_dnc`),
  KEY `idx_external_ids` (`convoso_lead_id`,`ghl_contact_id`),
  FULLTEXT KEY `idx_name` (`first_name`,`last_name`),
  CONSTRAINT `leads_ibfk_1` FOREIGN KEY (`campaign_id`) REFERENCES `campaigns` (`id`) ON DELETE CASCADE,
  CONSTRAINT `leads_ibfk_2` FOREIGN KEY (`import_id`) REFERENCES `file_imports` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=350 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Core lead records from import through conversion. 10M+ rows expected.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leads`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `leads` DISABLE KEYS */;
INSERT INTO `leads` VALUES
(1,1,9,'L001','John','Smith','5551234567','john.smith@email.com','123 Main Street','Los Angeles','CA','90001',45,450000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(2,1,9,'L002','Sarah','Johnson','5559876543','sarah.johnson@gmail.com','456 Oak Avenue','San Diego','CA','92101',38,525000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(3,1,9,'L003','Michael','Williams','5555551234','michael.w@yahoo.com','789 Pine Road','San Francisco','CA','94102',52,785000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(4,1,9,'L004','Jennifer','Brown','5558889999','jennifer.brown@outlook.com','321 Elm Street','Sacramento','CA','95814',41,365000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(5,1,9,'L005','David','Martinez','5552223333','david.martinez@hotmail.com','654 Maple Drive','Fresno','CA','93650',48,295000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(6,1,9,'L006','Lisa','Garcia','5557778888','lisa.garcia@email.com','987 Cedar Lane','Long Beach','CA','90802',35,475000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(7,1,9,'L007','Robert','Rodriguez','5554445555','robert.r@gmail.com','147 Birch Court','Oakland','CA','94601',56,550000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(8,1,9,'L008','Maria','Martinez','5556667777','maria.martinez@yahoo.com','258 Spruce Way','Bakersfield','CA','93301',42,315000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(9,1,9,'L009','James','Anderson','5553334444','james.anderson@outlook.com','369 Willow Street','Anaheim','CA','92801',50,425000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(10,1,9,'L010','Patricia','Taylor','5559990000','patricia.taylor@email.com','741 Aspen Avenue','Santa Ana','CA','92701',39,395000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(11,1,9,'L011','Christopher','Thomas','5551112222','chris.thomas@gmail.com','852 Redwood Drive','Riverside','CA','92501',44,345000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(12,1,9,'L012','Linda','Moore','5558887777','linda.moore@yahoo.com','963 Cypress Road','Stockton','CA','95202',47,285000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(13,1,9,'L013','Daniel','Jackson','5552229999','daniel.jackson@hotmail.com','159 Hickory Lane','Irvine','CA','92602',36,625000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(14,1,9,'L014','Barbara','White','5556665555','barbara.white@email.com','357 Magnolia Court','Chula Vista','CA','91910',53,375000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(15,1,9,'L015','Matthew','Harris','5554443333','matthew.harris@gmail.com','486 Dogwood Street','Fremont','CA','94536',40,585000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(16,1,9,'L016','Elizabeth','Clark','5557776666','elizabeth.clark@outlook.com','791 Sycamore Way','San Bernardino','CA','92401',45,295000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(17,1,9,'L017','Joseph','Lewis','5553332222','joseph.lewis@yahoo.com','246 Cottonwood Avenue','Modesto','CA','95350',51,265000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(18,1,9,'L018','Susan','Walker','5558881111','susan.walker@email.com','135 Beech Drive','Fontana','CA','92335',38,325000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(19,1,9,'L019','Thomas','Hall','5556664444','thomas.hall@gmail.com','579 Walnut Road','Oxnard','CA','93030',49,435000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(20,1,9,'L020','Jessica','Allen','5554448888','jessica.allen@hotmail.com','802 Chestnut Lane','Moreno Valley','CA','92553',33,285000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(21,1,9,'L021','Charles','Young','5552221111','charles.young@outlook.com','913 Poplar Court','Glendale','CA','91201',46,495000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(22,1,9,'L022','Karen','King','5559998888','karen.king@email.com','468 Alder Street','Huntington Beach','CA','92648',41,565000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(23,1,9,'L023','Mark','Wright','5551117777','mark.wright@yahoo.com','357 Fir Avenue','Santa Clarita','CA','91350',55,425000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(24,1,9,'L024','Nancy','Lopez','5558886666','nancy.lopez@gmail.com','642 Laurel Way','Garden Grove','CA','92840',37,385000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(25,1,9,'L025','Steven','Hill','5553336666','steven.hill@hotmail.com','789 Hemlock Drive','Oceanside','CA','92054',48,445000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(26,1,9,'L026','Betty','Scott','5556669999','betty.scott@email.com','951 Juniper Road','Corona','CA','92879',43,365000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(27,1,9,'L027','Paul','Green','5554442222','paul.green@outlook.com','753 Cedar Court','Lancaster','CA','93534',52,245000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(28,1,9,'L028','Sandra','Adams','5557775555','sandra.adams@yahoo.com','864 Pine Street','Palmdale','CA','93550',39,255000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(29,1,9,'L029','Kevin','Baker','5552228888','kevin.baker@gmail.com','159 Oak Lane','Salinas','CA','93901',44,395000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(30,1,9,'L030','Donna','Gonzalez','5559997777','donna.gonzalez@email.com','267 Maple Avenue','Pomona','CA','91766',50,335000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(31,1,9,'L031','George','Nelson','5551116666','george.nelson@hotmail.com','378 Elm Way','Escondido','CA','92025',47,385000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(32,1,9,'L032','Carol','Carter','5558885555','carol.carter@outlook.com','489 Birch Drive','Torrance','CA','90501',35,525000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(33,1,9,'L033','Ronald','Mitchell','5553335555','ronald.mitchell@yahoo.com','591 Spruce Road','Pasadena','CA','91101',54,575000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(34,1,9,'L034','Michelle','Perez','5556668888','michelle.perez@gmail.com','642 Willow Court','Orange','CA','92866',40,465000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(35,1,9,'L035','Jason','Roberts','5554447777','jason.roberts@email.com','753 Aspen Street','Fullerton','CA','92832',36,425000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(36,1,9,'L036','Dorothy','Turner','5557774444','dorothy.turner@hotmail.com','864 Redwood Avenue','Costa Mesa','CA','92626',58,485000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(37,1,9,'L037','Brian','Phillips','5552227777','brian.phillips@outlook.com','975 Cypress Lane','Carlsbad','CA','92008',42,545000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(38,1,9,'L038','Emily','Campbell','5559996666','emily.campbell@yahoo.com','186 Hickory Way','Fairfield','CA','94533',31,345000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(39,1,9,'L039','Joshua','Parker','5551115555','joshua.parker@gmail.com','297 Magnolia Drive','Arden-Arcade','CA','95825',45,375000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(40,1,9,'L040','Ashley','Evans','5558884444','ashley.evans@email.com','318 Dogwood Road','Santa Maria','CA','93454',38,315000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(41,1,9,'L041','Andrew','Edwards','5553334444','andrew.edwards@hotmail.com','429 Sycamore Court','Redding','CA','96001',51,265000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(42,1,9,'L042','Kimberly','Collins','5556667777','kimberly.collins@outlook.com','530 Cottonwood Street','Chico','CA','95926',39,285000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(43,1,9,'L043','Ryan','Stewart','5554446666','ryan.stewart@yahoo.com','641 Beech Avenue','San Mateo','CA','94401',47,685000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(44,1,9,'L044','Amanda','Sanchez','5557773333','amanda.sanchez@gmail.com','752 Walnut Way','Visalia','CA','93277',34,295000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(45,1,9,'L045','Nicholas','Morris','5552226666','nicholas.morris@email.com','863 Chestnut Drive','Roseville','CA','95678',43,415000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(46,1,9,'L046','Melissa','Rogers','5559995555','melissa.rogers@hotmail.com','974 Poplar Road','Concord','CA','94520',40,465000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(47,1,9,'L047','Anthony','Reed','5551114444','anthony.reed@outlook.com','185 Alder Court','Simi Valley','CA','93063',48,445000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(48,1,9,'L048','Stephanie','Cook','5558883333','stephanie.cook@yahoo.com','296 Fir Street','Thousand Oaks','CA','91360',36,525000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(49,1,9,'L049','Jonathan','Morgan','5553333333','jonathan.morgan@gmail.com','317 Laurel Avenue','Santa Rosa','CA','95401',52,425000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(50,1,9,'L050','Rebecca','Bell','5556666666','rebecca.bell@email.com','428 Hemlock Lane','Daly City','CA','94014',41,565000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(51,1,9,'L051','Eric','Murphy','5554445555','eric.murphy@hotmail.com','539 Juniper Way','Burbank','CA','91502',44,475000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(52,1,9,'L052','Laura','Bailey','5557772222','laura.bailey@outlook.com','640 Cedar Drive','Alameda','CA','94501',37,545000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(53,1,9,'L053','Jeffrey','Rivera','5552225555','jeffrey.rivera@yahoo.com','751 Pine Road','West Covina','CA','91790',50,385000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(54,1,9,'L054','Rachel','Cooper','5559994444','rachel.cooper@gmail.com','862 Oak Court','Norwalk','CA','90650',33,365000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(55,1,9,'L055','Adam','Richardson','5551113333','adam.richardson@email.com','973 Maple Street','Richmond','CA','94801',46,425000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(56,1,9,'L056','Amy','Cox','5558882222','amy.cox@hotmail.com','184 Elm Avenue','Inglewood','CA','90301',39,395000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(57,1,9,'L057','Jacob','Howard','5553332222','jacob.howard@outlook.com','295 Birch Way','Berkeley','CA','94701',53,725000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(58,1,9,'L058','Julie','Ward','5556665555','julie.ward@yahoo.com','316 Spruce Drive','Downey','CA','90241',35,425000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(59,1,9,'L059','Tyler','Torres','5554444444','tyler.torres@gmail.com','427 Willow Road','Antioch','CA','94509',42,355000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(60,1,9,'L060','Samantha','Peterson','5557771111','samantha.peterson@email.com','538 Aspen Court','Temecula','CA','92590',38,425000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(61,1,9,'L061','Brandon','Gray','5552224444','brandon.gray@hotmail.com','649 Redwood Street','El Monte','CA','91731',48,345000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(62,1,9,'L062','Hannah','Ramirez','5559993333','hannah.ramirez@outlook.com','750 Cypress Avenue','Downey','CA','90242',32,375000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(63,1,9,'L063','Aaron','James','5551112222','aaron.james@yahoo.com','861 Hickory Lane','Hawthorne','CA','90250',45,425000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(64,1,9,'L064','Megan','Watson','5558881111','megan.watson@gmail.com','972 Magnolia Way','Carson','CA','90745',40,395000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(65,1,9,'L065','Justin','Brooks','5553331111','justin.brooks@email.com','183 Dogwood Drive','Santa Monica','CA','90401',51,825000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(66,1,9,'L066','Heather','Kelly','5556664444','heather.kelly@hotmail.com','294 Sycamore Road','Whittier','CA','90601',37,425000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(67,1,9,'L067','Kyle','Sanders','5554443333','kyle.sanders@outlook.com','315 Cottonwood Court','Newport Beach','CA','92660',49,985000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(68,1,9,'L068','Nicole','Price','5557770000','nicole.price@yahoo.com','426 Beech Street','Buena Park','CA','90620',34,385000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(69,1,9,'L069','Zachary','Bennett','5552223333','zachary.bennett@gmail.com','537 Walnut Avenue','Lakewood','CA','90712',43,425000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(70,1,9,'L070','Christina','Wood','5559992222','christina.wood@email.com','648 Chestnut Way','Menifee','CA','92584',39,345000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(71,1,9,'L071','Austin','Barnes','5551111111','austin.barnes@hotmail.com','759 Poplar Drive','Hemet','CA','92543',52,265000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(72,1,9,'L072','Lauren','Ross','5558880000','lauren.ross@outlook.com','860 Alder Road','Tracy','CA','95376',36,425000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(73,1,9,'L073','Gabriel','Henderson','5553330000','gabriel.henderson@yahoo.com','971 Fir Court','Indio','CA','92201',47,295000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(74,1,9,'L074','Victoria','Coleman','5556663333','victoria.coleman@gmail.com','182 Laurel Street','Clovis','CA','93611',41,365000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(75,1,9,'L075','Jordan','Jenkins','5554442222','jordan.jenkins@email.com','293 Hemlock Avenue','Santa Barbara','CA','93101',38,785000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(76,1,9,'L076','Alexis','Perry','5557779999','alexis.perry@hotmail.com','314 Juniper Lane','Merced','CA','95340',33,245000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(77,1,9,'L077','Dylan','Powell','5552222222','dylan.powell@outlook.com','425 Cedar Way','El Cajon','CA','92020',50,365000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(78,1,9,'L078','Brittany','Long','5559991111','brittany.long@yahoo.com','536 Pine Drive','Tustin','CA','92780',35,485000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(79,1,9,'L079','Nathan','Patterson','5551110000','nathan.patterson@gmail.com','647 Oak Road','Lake Forest','CA','92630',44,525000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(80,1,9,'L080','Courtney','Hughes','5558889999','courtney.hughes@email.com','758 Maple Court','San Marcos','CA','92069',39,425000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(81,1,9,'L081','Ethan','Flores','5553339999','ethan.flores@hotmail.com','869 Elm Street','Pleasanton','CA','94566',46,625000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(82,1,9,'L082','Danielle','Washington','5556662222','danielle.washington@outlook.com','970 Birch Avenue','Mission Viejo','CA','92691',37,565000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(83,1,9,'L083','Sean','Butler','5554441111','sean.butler@yahoo.com','181 Spruce Way','Redondo Beach','CA','90277',53,685000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(84,1,9,'L084','Diana','Simmons','5557778888','diana.simmons@gmail.com','292 Willow Drive','Perris','CA','92570',31,285000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(85,1,9,'L085','Cody','Foster','5552221111','cody.foster@email.com','313 Aspen Road','Manteca','CA','95336',42,355000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(86,1,9,'L086','Kathryn','Gonzales','5559990000','kathryn.gonzales@hotmail.com','424 Redwood Court','Vacaville','CA','95687',40,395000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(87,1,9,'L087','Jesse','Bryant','5551119999','jesse.bryant@outlook.com','535 Cypress Street','Citrus Heights','CA','95610',48,345000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(88,1,9,'L088','Kelly','Alexander','5558888888','kelly.alexander@yahoo.com','646 Hickory Avenue','Hawthorne','CA','90251',36,425000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(89,1,9,'L089','Jeremy','Russell','5553338888','jeremy.russell@gmail.com','757 Magnolia Lane','Pittsburg','CA','94565',51,385000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(90,1,9,'L090','Anna','Griffin','5556661111','anna.griffin@email.com','868 Dogwood Way','Tracy','CA','95377',38,415000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(91,1,9,'L091','Trevor','Diaz','5554440000','trevor.diaz@hotmail.com','979 Sycamore Drive','Upland','CA','91784',45,425000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(92,1,9,'L092','Sara','Hayes','5557777777','sara.hayes@outlook.com','180 Cottonwood Road','Livermore','CA','94550',39,525000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(93,1,9,'L093','Cameron','Myers','5552220000','cameron.myers@yahoo.com','291 Beech Court','Lake Elsinore','CA','92530',47,325000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(94,1,9,'L094','Kayla','Ford','5559999999','kayla.ford@gmail.com','312 Walnut Street','Petaluma','CA','94952',34,485000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(95,1,9,'L095','Connor','Hamilton','5551118888','connor.hamilton@email.com','423 Chestnut Avenue','Westminster','CA','92683',43,425000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(96,1,9,'L096','Monica','Graham','5558887777','monica.graham@hotmail.com','534 Poplar Way','Dublin','CA','94568',41,585000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(97,1,9,'L097','Adrian','Sullivan','5553337777','adrian.sullivan@outlook.com','645 Alder Drive','San Leandro','CA','94577',49,465000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(98,1,9,'L098','Jasmine','Wallace','5556660000','jasmine.wallace@yahoo.com','756 Fir Road','Lynwood','CA','90262',32,325000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(99,1,9,'L099','Lucas','Woods','5554449999','lucas.woods@gmail.com','867 Laurel Court','Baldwin Park','CA','91706',46,355000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(100,1,9,'L100','Andrea','Cole','5557776666','andrea.cole@email.com','978 Hemlock Street','Napa','CA','94558',38,625000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(101,1,9,'L101','123','TestFail','','invalid@','456 Bad Street','Unknown','XX','99999',25,100000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(102,1,9,'L102','Jane','','5551234567','jane@email.com','789 Test Ave','TestCity','CA','90001',30,250000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(103,1,9,'L103','Invalid','Phone','123','bad.email@test.com','321 Sample Rd','SampleCity','CA','90002',40,300000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(104,1,9,'L104','Duplicate','Record','5551234567','duplicate@test.com','999 Dup Lane','DupCity','CA','90003',35,280000.00,NULL,NULL,'2024-03-01','2024-03-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(105,1,9,'L105','Old','ScrubDate','5559999999','old@email.com','111 Old Street','OldCity','CA','90004',50,350000.00,NULL,NULL,'2024-01-01','2024-01-31',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 12:55:29','2026-03-19 06:41:39'),
(106,1,10,'L001','John','Smith','5551234567','john@example.com','123 Main St','Anytown','CA','12345',45,350000.00,NULL,NULL,'2024-02-15','2024-03-16',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 13:30:37','2026-03-19 06:41:39'),
(107,1,10,'L002','Jane','Doe','5555678901','jane@example.com','456 Oak Ave','Dallas','TX','75201',38,275000.00,NULL,NULL,'2024-02-15','2024-03-16',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-14 13:30:37','2026-03-19 06:41:39'),
(108,1,11,'L001','John','Smith','5551234567','john@example.com','123 Main St','Anytown','CA','12345',45,350000.00,NULL,NULL,'2024-02-15','2024-03-16',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-16 06:42:58','2026-03-19 06:41:39'),
(109,1,11,'L002','Jane','Doe','5555678901','jane@example.com','456 Oak Ave','Dallas','TX','75201',38,275000.00,NULL,NULL,'2024-02-15','2024-03-16',0,NULL,NULL,'imported',NULL,NULL,NULL,NULL,'2026-03-16 06:42:58','2026-03-19 06:41:39'),
(225,1,15,'L001','James','Harrington','6195550101','james.harrington@gmail.com','742 Evergreen Terrace','San Diego','CA','92101',47,520000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"100k-150k\", \"qualityscore\": \"88\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 11:34:21','2026-03-19 06:41:39'),
(226,1,15,'L002','Maria','Delgado','3105550182','maria.delgado@outlook.com','1600 Amphitheatre Pkwy','Los Angeles','CA','90001',39,375000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"75k-100k\", \"qualityscore\": \"76\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 11:34:21','2026-03-19 06:41:39'),
(227,1,15,'L003','Robert','Chen','4155550193','robert.chen@yahoo.com','221B Baker Street','San Francisco','CA','94102',54,810000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"150k-200k\", \"qualityscore\": \"92\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 11:34:21','2026-03-19 06:41:39'),
(228,1,15,'L004','Ashley','Williams','9165550147','ashley.williams@hotmail.com','350 Fifth Avenue','Sacramento','CA','95814',33,295000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"50k-75k\", \"qualityscore\": \"65\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 11:34:21','2026-03-19 06:41:39'),
(229,1,15,'L005','Daniel','Okafor','8585550168','daniel.okafor@gmail.com','1 Infinite Loop','Irvine','CA','92602',42,645000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"150k-200k\", \"qualityscore\": \"81\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 11:34:21','2026-03-19 06:41:39'),
(230,1,16,'L001','Raymond','Anderson','3109595506','raymond.anderson55@gmail.com','2386 Cedar Ln','San Bernardino','CA','92438',62,265000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"150k-200k\", \"qualityscore\": \"61\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(231,1,16,'L002','Patricia','Ramirez','5597171434','patricia.ramirez36@aol.com','9028 Hilltop Ln','Gilbert','AZ','85235',42,620000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"150k-200k\", \"qualityscore\": \"60\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(232,1,16,'L003','Andrea','Lee','2105485552','andrea.lee46@aol.com','5614 Cedar Ln','Santa Ana','CA','92737',33,545000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"30k-50k\", \"qualityscore\": \"82\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(233,1,16,'L004','Joyce','King','4159478527','joyce.king80@aol.com','6301 Maple Dr','Scottsdale','AZ','85225',63,450000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"200k+\", \"qualityscore\": \"83\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(234,1,16,'L005','Janet','Harris','8582464733','janet.harris59@icloud.com','1407 Birch Blvd','Tampa','FL','33647',34,545000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"75k-100k\", \"qualityscore\": \"83\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(235,1,16,'L006','Daniel','Mitchell','6234145374','daniel.mitchell94@yahoo.com','1269 Brookside Dr','Denver','CO','80297',68,345000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"150k-200k\", \"qualityscore\": \"70\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(236,1,16,'L007','Shirley','Carter','7608554598','shirley.carter35@gmail.com','1016 Birch Blvd','Portland','OR','97251',30,475000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"100k-150k\", \"qualityscore\": \"73\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(237,1,16,'L008','Christine','Sullivan','4804179179','christine.sullivan96@email.com','7617 Pine Rd','Corona','CA','92892',44,315000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"50k-75k\", \"qualityscore\": \"94\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(238,1,16,'L009','Kimberly','Gutierrez','2107977543','kimberly.gutierrez15@yahoo.com','2366 Forest Dr','Garden Grove','CA','92838',59,265000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"30k-50k\", \"qualityscore\": \"70\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(239,1,16,'L010','Aaron','Collins','8585947252','aaron.collins93@gmail.com','8769 Sunset Blvd','Dallas','TX','75269',63,185000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"200k+\", \"qualityscore\": \"94\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(240,1,16,'L011','Megan','Wright','6023145808','megan.wright65@gmail.com','7533 Main St','Palmdale','CA','93530',44,710000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"50k-75k\", \"qualityscore\": \"79\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(241,1,16,'L012','Raymond','Reed','8313567126','raymond.reed63@gmail.com','8937 Forest Dr','Orlando','FL','32830',28,895000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"75k-100k\", \"qualityscore\": \"67\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(242,1,16,'L013','Ryan','Flores','6612594946','ryan.flores17@icloud.com','1503 Meadow Ln','Houston','TX','77020',32,760000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"50k-75k\", \"qualityscore\": \"90\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(243,1,16,'L014','Virginia','Perez','8057407932','virginia.perez67@hotmail.com','3395 Highland Ave','Chula Vista','CA','91979',53,510000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"100k-150k\", \"qualityscore\": \"67\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(244,1,16,'L015','Ashley','Lewis','8585461344','ashley.lewis91@icloud.com','3870 Orchard Rd','San Antonio','TX','78280',42,185000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"30k-50k\", \"qualityscore\": \"63\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(245,1,16,'L016','George','Rodriguez','4155382160','george.rodriguez93@email.com','4662 Meadow Ln','Mesa','AZ','85240',41,760000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"50k-75k\", \"qualityscore\": \"96\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(246,1,16,'L017','Eric','Young','7206164119','eric.young94@gmail.com','7162 Lakeshore Rd','Oakland','CA','94622',55,580000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"100k-150k\", \"qualityscore\": \"66\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(247,1,16,'L018','Joseph','Evans','6023115073','joseph.evans36@hotmail.com','8886 Riverside Dr','Irvine','CA','92634',36,580000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"50k-75k\", \"qualityscore\": \"75\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(248,1,16,'L019','Charles','Stewart','8133001828','charles.stewart63@hotmail.com','341 Maple Dr','El Paso','TX','79979',43,345000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"100k-150k\", \"qualityscore\": \"73\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(249,1,16,'L020','Stephanie','Davis','4085881035','stephanie.davis92@hotmail.com','7554 Highland Ave','Oceanside','CA','92043',55,760000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"200k+\", \"qualityscore\": \"69\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(250,1,16,'L021','Mark','Nguyen','2092599883','mark.nguyen68@yahoo.com','1036 Oak Ave','Sacramento','CA','95850',65,665000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"150k-200k\", \"qualityscore\": \"63\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(251,1,16,'L022','Scott','Hernandez','6502702113','scott.hernandez77@gmail.com','6715 Cedar Ln','Portland','OR','97240',64,395000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"150k-200k\", \"qualityscore\": \"65\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(252,1,16,'L023','Sharon','Myers','3055235272','sharon.myers86@icloud.com','5247 Birch Blvd','Chula Vista','CA','91995',44,545000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"50k-75k\", \"qualityscore\": \"79\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(253,1,16,'L024','Angela','Green','8582098508','angela.green34@yahoo.com','1738 Maple Dr','Austin','TX','78782',62,375000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"150k-200k\", \"qualityscore\": \"82\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(254,1,16,'L025','Thomas','Young','5204913584','thomas.young71@outlook.com','5056 Brookside Dr','Salinas','CA','93979',61,185000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"200k+\", \"qualityscore\": \"66\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(255,1,16,'L026','Sarah','King','8183093546','sarah.king63@outlook.com','3550 Parkview Dr','Fontana','CA','92346',41,425000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"150k-200k\", \"qualityscore\": \"63\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(256,1,16,'L027','Patricia','Cruz','2104831722','patricia.cruz91@hotmail.com','2243 Sunset Blvd','Los Angeles','CA','90052',38,620000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"150k-200k\", \"qualityscore\": \"95\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(257,1,16,'L028','John','Anderson','8589073442','john.anderson17@gmail.com','6149 Orchard Rd','Scottsdale','AZ','85214',63,315000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"100k-150k\", \"qualityscore\": \"79\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(258,1,16,'L029','Ryan','Garcia','6234155088','ryan.garcia20@yahoo.com','5894 Summit Ave','Seattle','WA','98123',54,895000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"200k+\", \"qualityscore\": \"70\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(259,1,16,'L030','Anthony','Turner','3103836442','anthony.turner5@aol.com','4165 Sunset Blvd','Lancaster','CA','93595',38,295000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"100k-150k\", \"qualityscore\": \"90\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(260,1,16,'L031','Kenneth','Sanchez','5035586000','kenneth.sanchez9@aol.com','487 Willow Way','Fremont','CA','94538',53,475000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"75k-100k\", \"qualityscore\": \"77\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(261,1,16,'L032','Jason','Hughes','4046099785','jason.hughes5@gmail.com','1989 Sunset Blvd','Huntington Beach','CA','92613',39,820000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"75k-100k\", \"qualityscore\": \"98\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(262,1,16,'L033','Cynthia','Hall','4806469379','cynthia.hall56@gmail.com','9546 Willow Way','Bakersfield','CA','93359',44,225000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"200k+\", \"qualityscore\": \"93\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(263,1,16,'L034','Samuel','Sanders','8315728066','samuel.sanders39@email.com','5509 Brookside Dr','Fresno','CA','93795',48,295000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"200k+\", \"qualityscore\": \"79\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(264,1,16,'L035','Jerry','Turner','4806125844','jerry.turner73@outlook.com','3243 Hilltop Ln','Gilbert','AZ','85226',52,345000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"150k-200k\", \"qualityscore\": \"85\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(265,1,16,'L036','Virginia','Smith','6264934443','virginia.smith28@email.com','5379 Riverside Dr','Palmdale','CA','93584',56,620000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"200k+\", \"qualityscore\": \"90\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(266,1,16,'L037','Judith','Perez','9494909445','judith.perez26@yahoo.com','5591 Maple Dr','Seattle','WA','98191',43,450000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"50k-75k\", \"qualityscore\": \"61\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(267,1,16,'L038','David','Young','7208252193','david.young32@yahoo.com','9531 Willow Way','Pomona','CA','91763',52,665000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"100k-150k\", \"qualityscore\": \"60\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(268,1,16,'L039','Megan','Barnes','7149977965','megan.barnes16@hotmail.com','8586 Riverside Dr','Fremont','CA','94532',31,760000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"50k-75k\", \"qualityscore\": \"68\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(269,1,16,'L040','Shirley','Long','3057726198','shirley.long96@aol.com','8370 Hilltop Ln','Orlando','FL','32866',63,620000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"50k-75k\", \"qualityscore\": \"90\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(270,1,16,'L041','Amy','King','6618525543','amy.king92@outlook.com','8039 Birch Blvd','Tampa','FL','33676',45,620000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"30k-50k\", \"qualityscore\": \"75\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(271,1,16,'L042','Emily','Nelson','4807532320','emily.nelson54@hotmail.com','3888 Valley Rd','Anaheim','CA','92829',37,375000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"30k-50k\", \"qualityscore\": \"81\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:25','2026-03-19 06:41:39'),
(272,1,16,'L043','Frank','Cook','5122634388','frank.cook1@outlook.com','9669 Main St','Lancaster','CA','93559',64,545000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"100k-150k\", \"qualityscore\": \"79\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(273,1,16,'L044','Megan','Roberts','5127519947','megan.roberts4@hotmail.com','8099 Birch Blvd','Dallas','TX','75238',45,580000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"100k-150k\", \"qualityscore\": \"81\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(274,1,16,'L045','Jerry','Foster','2149413704','jerry.foster85@gmail.com','8851 Main St','Pomona','CA','91726',53,820000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"150k-200k\", \"qualityscore\": \"65\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(275,1,16,'L046','Patrick','Collins','2136723977','patrick.collins44@aol.com','6311 Parkview Dr','Sacramento','CA','95843',41,620000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"75k-100k\", \"qualityscore\": \"84\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(276,1,16,'L047','Donna','Perry','5124582341','donna.perry9@aol.com','8937 Oak Ave','Phoenix','AZ','85012',50,395000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"200k+\", \"qualityscore\": \"62\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(277,1,16,'L048','Megan','Brown','6614041333','megan.brown28@hotmail.com','4008 Pine Rd','Austin','TX','78729',58,295000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"150k-200k\", \"qualityscore\": \"76\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(278,1,16,'L049','Hannah','Mitchell','4088202876','hannah.mitchell74@icloud.com','5196 Cedar Ln','Tampa','FL','33630',65,185000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"75k-100k\", \"qualityscore\": \"84\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(279,1,16,'L050','Deborah','Sullivan','8312774978','deborah.sullivan45@email.com','5041 Brookside Dr','Oakland','CA','94699',35,820000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"30k-50k\", \"qualityscore\": \"87\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(280,1,16,'L051','Dennis','Mitchell','8587186590','dennis.mitchell59@icloud.com','8131 Cedar Ln','Los Angeles','CA','90063',55,510000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"200k+\", \"qualityscore\": \"69\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(281,1,16,'L052','Cynthia','Thompson','3058665425','cynthia.thompson42@aol.com','8021 Riverside Dr','Austin','TX','78778',55,820000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"75k-100k\", \"qualityscore\": \"75\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(282,1,16,'L053','Patricia','Scott','2064498613','patricia.scott24@hotmail.com','6309 Parkview Dr','Houston','TX','77088',29,665000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"75k-100k\", \"qualityscore\": \"73\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(283,1,16,'L054','Jeffrey','King','6024865526','jeffrey.king53@hotmail.com','8564 Willow Way','Gilbert','AZ','85211',33,395000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"200k+\", \"qualityscore\": \"95\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(284,1,16,'L055','Andrea','Walker','7208619041','andrea.walker32@outlook.com','1624 Highland Ave','Salinas','CA','93912',42,545000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"200k+\", \"qualityscore\": \"97\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(285,1,16,'L056','Jacob','Rogers','8137436632','jacob.rogers33@yahoo.com','5519 Lakeshore Rd','Palmdale','CA','93580',57,425000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"75k-100k\", \"qualityscore\": \"67\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(286,1,16,'L057','Evelyn','Harris','4803229779','evelyn.harris93@email.com','3133 Willow Way','Orlando','FL','32898',41,665000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"75k-100k\", \"qualityscore\": \"93\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(287,1,16,'L058','Ann','Torres','7143985853','ann.torres36@gmail.com','3039 Highland Ave','Fremont','CA','94556',28,760000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"50k-75k\", \"qualityscore\": \"63\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(288,1,16,'L059','Virginia','Nguyen','2138539042','virginia.nguyen44@yahoo.com','9505 Highland Ave','Oakland','CA','94611',58,665000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"100k-150k\", \"qualityscore\": \"63\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(289,1,16,'L060','Dorothy','Morgan','8182667565','dorothy.morgan39@gmail.com','9553 Oak Ave','Tucson','AZ','85719',37,315000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"150k-200k\", \"qualityscore\": \"75\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(290,1,16,'L061','Susan','Cox','5128204697','susan.cox55@outlook.com','6332 Riverside Dr','Tampa','FL','33676',56,450000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"150k-200k\", \"qualityscore\": \"96\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(291,1,16,'L062','Alice','Davis','7149814404','alice.davis71@gmail.com','4435 Maple Dr','Fort Worth','TX','76137',38,395000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"50k-75k\", \"qualityscore\": \"70\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(292,1,16,'L063','James','Turner','2069058699','james.turner88@yahoo.com','3892 Highland Ave','Oxnard','CA','93014',46,620000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"30k-50k\", \"qualityscore\": \"76\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(293,1,16,'L064','Gregory','Watson','8316352880','gregory.watson22@aol.com','2541 Sunset Blvd','Scottsdale','AZ','85238',37,265000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"30k-50k\", \"qualityscore\": \"79\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(294,1,16,'L065','Ann','Gutierrez','5626493037','ann.gutierrez64@hotmail.com','5082 Valley Rd','Pomona','CA','91798',45,710000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"150k-200k\", \"qualityscore\": \"65\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(295,1,16,'L066','Ann','Garcia','2109526280','ann.garcia3@aol.com','523 Maple Dr','Dallas','TX','75242',42,820000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"150k-200k\", \"qualityscore\": \"77\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(296,1,16,'L067','Janet','Garcia','6506819502','janet.garcia63@gmail.com','4657 Elm St','El Paso','TX','79966',65,580000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"200k+\", \"qualityscore\": \"90\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(297,1,16,'L068','Jason','Turner','6025282713','jason.turner5@hotmail.com','6844 Meadow Ln','Riverside','CA','92552',46,545000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"150k-200k\", \"qualityscore\": \"65\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(298,1,16,'L069','Edward','Allen','4803187622','edward.allen67@outlook.com','8989 Riverside Dr','Mesa','AZ','85210',54,225000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"50k-75k\", \"qualityscore\": \"91\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(299,1,16,'L070','Gregory','Stewart','9164085375','gregory.stewart81@email.com','4819 Riverside Dr','Gilbert','AZ','85226',59,295000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"30k-50k\", \"qualityscore\": \"75\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(300,1,16,'L071','Julie','Lee','6267641224','julie.lee83@aol.com','1627 Birch Blvd','Gilbert','AZ','85262',35,620000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"30k-50k\", \"qualityscore\": \"69\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(301,1,16,'L072','Larry','Sullivan','5627215479','larry.sullivan50@yahoo.com','7836 Birch Blvd','Lancaster','CA','93571',57,760000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"50k-75k\", \"qualityscore\": \"98\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(302,1,16,'L073','Scott','Gutierrez','2132715526','scott.gutierrez93@outlook.com','5668 Forest Dr','Tampa','FL','33663',45,185000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"75k-100k\", \"qualityscore\": \"97\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(303,1,16,'L074','Catherine','Myers','7023528316','catherine.myers59@outlook.com','5754 Parkview Dr','Scottsdale','AZ','85271',63,760000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"100k-150k\", \"qualityscore\": \"72\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(304,1,16,'L075','Henry','Walker','7134397730','henry.walker5@yahoo.com','7849 Valley Rd','San Francisco','CA','94150',52,315000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"100k-150k\", \"qualityscore\": \"92\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(305,1,16,'L076','Frances','Nelson','7146502633','frances.nelson61@aol.com','351 Pine Rd','Chandler','AZ','85268',54,315000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"30k-50k\", \"qualityscore\": \"76\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(306,1,16,'L077','Timothy','James','2148652315','timothy.james5@email.com','8842 Valley Rd','Huntington Beach','CA','92696',48,665000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"150k-200k\", \"qualityscore\": \"64\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(307,1,16,'L078','Sandra','Reyes','5624322480','sandra.reyes6@outlook.com','1746 Riverside Dr','Palmdale','CA','93522',38,450000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"30k-50k\", \"qualityscore\": \"63\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(308,1,16,'L079','Carol','Rivera','5206413385','carol.rivera11@email.com','6851 Orchard Rd','San Bernardino','CA','92477',39,345000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"50k-75k\", \"qualityscore\": \"84\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(309,1,16,'L080','Alice','Sanders','6617093344','alice.sanders37@icloud.com','4261 Riverside Dr','Fremont','CA','94569',44,185000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"100k-150k\", \"qualityscore\": \"94\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(310,1,16,'L081','Daniel','Martinez','2065535901','daniel.martinez62@gmail.com','4197 Riverside Dr','Fort Worth','TX','76164',47,375000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"100k-150k\", \"qualityscore\": \"75\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(311,1,16,'L082','Gary','Richardson','6237885847','gary.richardson88@aol.com','459 Valley Rd','Denver','CO','80247',45,185000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"150k-200k\", \"qualityscore\": \"63\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(312,1,16,'L083','Joyce','Gutierrez','7024934770','joyce.gutierrez97@icloud.com','3688 Willow Way','Dallas','TX','75255',67,425000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"200k+\", \"qualityscore\": \"68\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(313,1,16,'L084','Gregory','Gonzalez','4155168222','gregory.gonzalez96@hotmail.com','6077 Pine Rd','San Francisco','CA','94184',33,450000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"75k-100k\", \"qualityscore\": \"71\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(314,1,16,'L085','Paul','Taylor','4075749697','paul.taylor44@aol.com','2795 Sunset Blvd','Mesa','AZ','85244',58,450000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"200k+\", \"qualityscore\": \"67\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(315,1,16,'L086','Shirley','Martinez','3239724696','shirley.martinez2@outlook.com','6611 Summit Ave','Portland','OR','97296',51,265000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"100k-150k\", \"qualityscore\": \"94\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(316,1,16,'L087','Susan','Murphy','5208885295','susan.murphy80@email.com','6186 Cedar Ln','San Antonio','TX','78258',42,665000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"30k-50k\", \"qualityscore\": \"80\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(317,1,16,'L088','Diane','Lewis','8588508606','diane.lewis39@hotmail.com','6789 Cedar Ln','Denver','CO','80248',36,225000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"30k-50k\", \"qualityscore\": \"67\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(318,1,16,'L089','Jennifer','Walker','4073387367','jennifer.walker84@gmail.com','8950 Hilltop Ln','Pomona','CA','91757',65,315000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"100k-150k\", \"qualityscore\": \"91\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(319,1,16,'L090','Diane','Turner','7602337070','diane.turner48@email.com','7385 Birch Blvd','Chula Vista','CA','91966',51,295000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"200k+\", \"qualityscore\": \"82\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(320,1,16,'L091','Joseph','Phillips','7603943001','joseph.phillips32@yahoo.com','3575 Brookside Dr','Pomona','CA','91721',29,225000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"75k-100k\", \"qualityscore\": \"96\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(321,1,16,'L092','Steven','Rodriguez','8134124538','steven.rodriguez17@email.com','2517 Brookside Dr','Fremont','CA','94552',28,425000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"50k-75k\", \"qualityscore\": \"76\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(322,1,16,'L093','Anthony','Anderson','3103341243','anthony.anderson7@yahoo.com','9747 Parkview Dr','Santa Clarita','CA','91340',29,345000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"75k-100k\", \"qualityscore\": \"86\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(323,1,16,'L094','Benjamin','Anderson','8586878344','benjamin.anderson29@email.com','8508 Orchard Rd','Tampa','FL','33656',34,620000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"150k-200k\", \"qualityscore\": \"62\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(324,1,16,'L095','Martha','Myers','3055088504','martha.myers14@hotmail.com','1096 Meadow Ln','El Paso','TX','79913',53,580000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"200k+\", \"qualityscore\": \"88\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(325,1,16,'L096','Charles','Hernandez','4808223430','charles.hernandez92@outlook.com','4605 Brookside Dr','Fresno','CA','93726',68,820000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"150k-200k\", \"qualityscore\": \"84\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(326,1,16,'L097','Ann','Gomez','5626649282','ann.gomez58@yahoo.com','1724 Cedar Ln','Dallas','TX','75265',63,375000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"100k-150k\", \"qualityscore\": \"86\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(327,1,16,'L098','Timothy','Murphy','2146252557','timothy.murphy61@gmail.com','5220 Sunset Blvd','Glendale','CA','91264',51,315000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"200k+\", \"qualityscore\": \"65\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(328,1,16,'L099','Mary','Lopez','2102987105','mary.lopez86@gmail.com','1082 Orchard Rd','Anaheim','CA','92881',63,760000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"75k-100k\", \"qualityscore\": \"86\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(329,1,16,'L100','Jeffrey','Long','2109381842','jeffrey.long28@yahoo.com','5219 Lakeshore Rd','Oxnard','CA','93086',34,820000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"150k-200k\", \"qualityscore\": \"90\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-16 13:12:26','2026-03-19 06:41:39'),
(335,1,18,'L001','James','Harrington','6195550101','james.harrington@gmail.com','742 Evergreen Terrace','San Diego','CA','92101',47,520000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"100k-150k\", \"qualityscore\": \"88\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-17 10:41:52','2026-03-19 06:41:39'),
(336,1,18,'L002','Maria','Delgado','3105550182','maria.delgado@outlook.com','1600 Amphitheatre Pkwy','Los Angeles','CA','90001',39,375000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"75k-100k\", \"qualityscore\": \"76\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-17 10:41:52','2026-03-19 06:41:39'),
(337,1,18,'L003','Robert','Chen','4155550193','robert.chen@yahoo.com','221B Baker Street','San Francisco','CA','94102',54,810000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"150k-200k\", \"qualityscore\": \"92\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-17 10:41:52','2026-03-19 06:41:39'),
(338,1,18,'L004','Ashley','Williams','9165550147','ashley.williams@hotmail.com','350 Fifth Avenue','Sacramento','CA','95814',33,295000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"50k-75k\", \"qualityscore\": \"65\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-17 10:41:52','2026-03-19 06:41:39'),
(339,1,18,'L005','Daniel','Okafor','8585550168','daniel.okafor@gmail.com','1 Infinite Loop','Irvine','CA','92602',42,645000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"150k-200k\", \"qualityscore\": \"81\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-17 10:41:52','2026-03-19 06:41:39'),
(340,1,19,'L001','James','Harrington','6195550101','james.harrington@gmail.com','742 Evergreen Terrace','San Diego','CA','92101',47,520000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"100k-150k\", \"qualityscore\": \"88\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-17 11:04:11','2026-03-19 06:41:39'),
(341,1,19,'L002','Maria','Delgado','3105550182','maria.delgado@outlook.com','1600 Amphitheatre Pkwy','Los Angeles','CA','90001',39,375000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"75k-100k\", \"qualityscore\": \"76\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-17 11:04:11','2026-03-19 06:41:39'),
(342,1,19,'L003','Robert','Chen','4155550193','robert.chen@yahoo.com','221B Baker Street','San Francisco','CA','94102',54,810000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"150k-200k\", \"qualityscore\": \"92\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-17 11:04:11','2026-03-19 06:41:39'),
(343,1,19,'L004','Ashley','Williams','9165550147','ashley.williams@hotmail.com','350 Fifth Avenue','Sacramento','CA','95814',33,295000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"50k-75k\", \"qualityscore\": \"65\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-17 11:04:11','2026-03-19 06:41:39'),
(344,1,19,'L005','Daniel','Okafor','8585550168','daniel.okafor@gmail.com','1 Infinite Loop','Irvine','CA','92602',42,645000.00,NULL,'{\"isdnc\": \"0\", \"dncreason\": \"\", \"incomerange\": \"150k-200k\", \"qualityscore\": \"81\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-17 11:04:11','2026-03-19 06:41:39'),
(345,1,20,'L001','James','Harrington','6195550101','james.harrington@gmail.com','742 Evergreen Terrace','San Diego','CA','92101',47,520000.00,NULL,'{\"incomerange\":\"100k-150k\",\"isdnc\":\"0\",\"dncreason\":\"\",\"qualityscore\":\"88\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-19 07:20:39','2026-03-19 07:20:39'),
(346,1,20,'L002','Maria','Delgado','3105550182','maria.delgado@outlook.com','1600 Amphitheatre Pkwy','Los Angeles','CA','90001',39,375000.00,NULL,'{\"incomerange\":\"75k-100k\",\"isdnc\":\"0\",\"dncreason\":\"\",\"qualityscore\":\"76\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-19 07:20:39','2026-03-19 07:20:39'),
(347,1,20,'L003','Robert','Chen','4155550193','robert.chen@yahoo.com','221B Baker Street','San Francisco','CA','94102',54,810000.00,NULL,'{\"incomerange\":\"150k-200k\",\"isdnc\":\"0\",\"dncreason\":\"\",\"qualityscore\":\"92\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-19 07:20:39','2026-03-19 07:20:39'),
(348,1,20,'L004','Ashley','Williams','9165550147','ashley.williams@hotmail.com','350 Fifth Avenue','Sacramento','CA','95814',33,295000.00,NULL,'{\"incomerange\":\"50k-75k\",\"isdnc\":\"0\",\"dncreason\":\"\",\"qualityscore\":\"65\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-19 07:20:39','2026-03-19 07:20:39'),
(349,1,20,'L005','Daniel','Okafor','8585550168','daniel.okafor@gmail.com','1 Infinite Loop','Irvine','CA','92602',42,645000.00,NULL,'{\"incomerange\":\"150k-200k\",\"isdnc\":\"0\",\"dncreason\":\"\",\"qualityscore\":\"81\"}','2026-03-16','2026-04-15',0,NULL,NULL,'validated',NULL,NULL,NULL,NULL,'2026-03-19 07:20:39','2026-03-19 07:20:39');
/*!40000 ALTER TABLE `leads` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `notification_type` enum('info','success','warning','error') DEFAULT 'info',
  `link_url` varchar(500) DEFAULT NULL COMMENT 'Optional deep link for the notification',
  `is_read` tinyint(1) DEFAULT 0,
  `read_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_read` (`is_read`),
  KEY `idx_created` (`created_at`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Per-user notification queue for dashboard alerts.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text NOT NULL,
  `setting_type` enum('string','number','boolean','json') DEFAULT 'string',
  `description` text DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`),
  KEY `idx_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Application configuration key-value store. Edit via admin UI.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `system_logs`
--

DROP TABLE IF EXISTS `system_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `log_level` enum('info','warning','error','critical') NOT NULL,
  `log_category` varchar(100) NOT NULL COMMENT 'import, api, validation, auth, cron, system',
  `message` text NOT NULL,
  `context` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Structured context data (lead_id, file, line, etc.)' CHECK (json_valid(`context`)),
  `user_id` int(10) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(500) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_level` (`log_level`),
  KEY `idx_category` (`log_category`),
  KEY `idx_user` (`user_id`),
  KEY `idx_created` (`created_at`),
  CONSTRAINT `system_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Application event log. All levels from info to critical.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_logs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `system_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_logs` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `role` enum('admin','manager','viewer') DEFAULT 'viewer',
  `status` enum('active','inactive') DEFAULT 'active',
  `last_login` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_email` (`email`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='System user accounts with role-based access control';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'admin','admin@landcaller.com','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','System Administrator','admin','active',NULL,'2026-03-14 09:42:58','2026-03-19 06:41:39');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `validation_errors`
--

DROP TABLE IF EXISTS `validation_errors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `validation_errors` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `import_id` int(10) unsigned NOT NULL,
  `csv_row_number` int(10) unsigned NOT NULL COMMENT 'Original row number in CSV file',
  `raw_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'Complete raw row data as key-value pairs' CHECK (json_valid(`raw_data`)),
  `errors` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'Array of error message strings' CHECK (json_valid(`errors`)),
  `is_fixed` tinyint(1) DEFAULT 0,
  `fixed_at` datetime DEFAULT NULL,
  `re_imported` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_import` (`import_id`),
  KEY `idx_status` (`is_fixed`,`re_imported`),
  CONSTRAINT `validation_errors_ibfk_1` FOREIGN KEY (`import_id`) REFERENCES `file_imports` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Failed import rows with full error details for review and re-import';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `validation_errors`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
/*!40000 ALTER TABLE `validation_errors` DISABLE KEYS */;
/*!40000 ALTER TABLE `validation_errors` ENABLE KEYS */;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Temporary table structure for view `vw_campaign_funnel`
--

DROP TABLE IF EXISTS `vw_campaign_funnel`;
/*!50001 DROP VIEW IF EXISTS `vw_campaign_funnel`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vw_campaign_funnel` AS SELECT
 NULL AS `campaign_id`,
 NULL AS `campaign_name`,
 NULL AS `total_leads`,
 NULL AS `validated`,
 NULL AS `failed_validation`,
 NULL AS `sent_to_convoso`,
 NULL AS `called`,
 NULL AS `qualified`,
 NULL AS `in_ghl`,
 NULL AS `converted`,
 NULL AS `conversion_pct` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_expiring_scrubs`
--

DROP TABLE IF EXISTS `vw_expiring_scrubs`;
/*!50001 DROP VIEW IF EXISTS `vw_expiring_scrubs`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vw_expiring_scrubs` AS SELECT
 NULL AS `id`,
 NULL AS `first_name`,
 NULL AS `last_name`,
 NULL AS `phone`,
 NULL AS `campaign_id`,
 NULL AS `scrub_date`,
 NULL AS `scrub_expiry_date`,
 NULL AS `days_remaining` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_qualified_pending_ghl`
--

DROP TABLE IF EXISTS `vw_qualified_pending_ghl`;
/*!50001 DROP VIEW IF EXISTS `vw_qualified_pending_ghl`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vw_qualified_pending_ghl` AS SELECT
 NULL AS `id`,
 NULL AS `campaign_id`,
 NULL AS `import_id`,
 NULL AS `lead_external_id`,
 NULL AS `first_name`,
 NULL AS `last_name`,
 NULL AS `phone`,
 NULL AS `email`,
 NULL AS `address`,
 NULL AS `city`,
 NULL AS `state`,
 NULL AS `zip`,
 NULL AS `age`,
 NULL AS `home_value`,
 NULL AS `income_range`,
 NULL AS `custom_data`,
 NULL AS `scrub_date`,
 NULL AS `scrub_expiry_date`,
 NULL AS `is_dnc`,
 NULL AS `dnc_date`,
 NULL AS `dnc_reason`,
 NULL AS `lead_status`,
 NULL AS `quality_score`,
 NULL AS `convoso_lead_id`,
 NULL AS `ghl_contact_id`,
 NULL AS `ghl_opportunity_id`,
 NULL AS `created_at`,
 NULL AS `updated_at`,
 NULL AS `call_disposition`,
 NULL AS `agent_name`,
 NULL AS `call_date`,
 NULL AS `recording_url`,
 NULL AS `campaign_name`,
 NULL AS `ghl_pipeline_id`,
 NULL AS `ghl_stage_id` */;
SET character_set_client = @saved_cs_client;

--
-- Dumping routines for database 'u353253270_lcds_db'
--

--
-- Final view structure for view `vw_campaign_funnel`
--

/*!50001 DROP VIEW IF EXISTS `vw_campaign_funnel`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_uca1400_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`u353253270_root`@`127.0.0.1` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_campaign_funnel` AS select `c`.`id` AS `campaign_id`,`c`.`campaign_name` AS `campaign_name`,count(`l`.`id`) AS `total_leads`,sum(`l`.`lead_status` = 'validated') AS `validated`,sum(`l`.`lead_status` = 'failed_validation') AS `failed_validation`,sum(`l`.`lead_status` = 'sent_to_convoso') AS `sent_to_convoso`,sum(`l`.`lead_status` in ('calling','called_no_answer','called_busy','called_voicemail','called_not_interested','called_callback','called_wrong_number')) AS `called`,sum(`l`.`lead_status` = 'qualified_lead') AS `qualified`,sum(`l`.`lead_status` in ('sent_to_ghl','converted')) AS `in_ghl`,sum(`l`.`lead_status` = 'converted') AS `converted`,round(sum(`l`.`lead_status` = 'converted') / nullif(count(`l`.`id`),0) * 100,2) AS `conversion_pct` from (`campaigns` `c` left join `leads` `l` on(`l`.`campaign_id` = `c`.`id`)) group by `c`.`id`,`c`.`campaign_name` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_expiring_scrubs`
--

/*!50001 DROP VIEW IF EXISTS `vw_expiring_scrubs`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_uca1400_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`u353253270_root`@`127.0.0.1` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_expiring_scrubs` AS select `l`.`id` AS `id`,`l`.`first_name` AS `first_name`,`l`.`last_name` AS `last_name`,`l`.`phone` AS `phone`,`l`.`campaign_id` AS `campaign_id`,`l`.`scrub_date` AS `scrub_date`,`l`.`scrub_expiry_date` AS `scrub_expiry_date`,to_days(`l`.`scrub_expiry_date`) - to_days(curdate()) AS `days_remaining` from `leads` `l` where `l`.`scrub_expiry_date` between curdate() and curdate() + interval 5 day and `l`.`is_dnc` = 0 and `l`.`lead_status` not in ('failed_validation','called_not_interested','called_wrong_number','converted') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_qualified_pending_ghl`
--

/*!50001 DROP VIEW IF EXISTS `vw_qualified_pending_ghl`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_uca1400_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`u353253270_root`@`127.0.0.1` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_qualified_pending_ghl` AS select `l`.`id` AS `id`,`l`.`campaign_id` AS `campaign_id`,`l`.`import_id` AS `import_id`,`l`.`lead_external_id` AS `lead_external_id`,`l`.`first_name` AS `first_name`,`l`.`last_name` AS `last_name`,`l`.`phone` AS `phone`,`l`.`email` AS `email`,`l`.`address` AS `address`,`l`.`city` AS `city`,`l`.`state` AS `state`,`l`.`zip` AS `zip`,`l`.`age` AS `age`,`l`.`home_value` AS `home_value`,`l`.`income_range` AS `income_range`,`l`.`custom_data` AS `custom_data`,`l`.`scrub_date` AS `scrub_date`,`l`.`scrub_expiry_date` AS `scrub_expiry_date`,`l`.`is_dnc` AS `is_dnc`,`l`.`dnc_date` AS `dnc_date`,`l`.`dnc_reason` AS `dnc_reason`,`l`.`lead_status` AS `lead_status`,`l`.`quality_score` AS `quality_score`,`l`.`convoso_lead_id` AS `convoso_lead_id`,`l`.`ghl_contact_id` AS `ghl_contact_id`,`l`.`ghl_opportunity_id` AS `ghl_opportunity_id`,`l`.`created_at` AS `created_at`,`l`.`updated_at` AS `updated_at`,`cr`.`call_disposition` AS `call_disposition`,`cr`.`agent_name` AS `agent_name`,`cr`.`call_date` AS `call_date`,`cr`.`recording_url` AS `recording_url`,`c`.`campaign_name` AS `campaign_name`,`c`.`ghl_pipeline_id` AS `ghl_pipeline_id`,`c`.`ghl_stage_id` AS `ghl_stage_id` from ((`leads` `l` join `call_results` `cr` on(`cr`.`lead_id` = `l`.`id` and `cr`.`is_qualified` = 1)) join `campaigns` `c` on(`c`.`id` = `l`.`campaign_id`)) where `l`.`lead_status` = 'qualified_lead' order by `cr`.`call_date` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-07-22  1:07:04
